#pragma once

#include "imgui.h"
#include "imgui_internal.h"

#include <string>
#include <atomic>

namespace login_page
{
    struct state
    {
        char  username[64] = "";
        char  password[64] = "";
        bool  remember_me = false;
        bool  auto_login = false;
        bool  show_password = false;
        bool  is_logged_in = false;
        bool  exit_pressed = false;
        bool  is_loading = false;
        float loading_timer = 0.f;
        float page_alpha = 1.0f;
        float error_timer = 0.f;
        char  status_text[128] = "";

        // KeyAuth authentication state
        bool  keyauth_authenticating = false;
        bool  keyauth_authenticated = false;
        char  keyauth_key[128] = "";
        bool  keyauth_show_key = false;
    };

    void draw(const ImRect& panel, state& st, bool& blocks_window_drag);
}

#pragma once

#include <windows.h>

struct ID3D11Device;

namespace gui
{
    inline bool g_menu_open = true;

    // Hide Panel hotkey state (shared with main.cpp)
    inline bool g_hide_panel_enabled = true;
    inline int  g_hide_panel_key = VK_INSERT;

    void initialize(ID3D11Device* device);
    void shutdown();
    void prepare_frame();
    void render(HWND hwnd);
    bool is_point_inside(float x, float y);
}
